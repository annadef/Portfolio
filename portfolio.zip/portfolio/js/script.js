$(document).ready(function () {
    // To add a fadein effect on cards when the page is loaded
    $(".project-box").hide().fadeIn(3000);
});